const { Component, mount } = owl;
const { xml } = owl.tags;



export class client_profile extends Component {
  static template = xml`<div>   
            <div class="mb-5 ml-5 mt-5">
                <div class="row">
                    <h1>Client Profile</h1> 
                </div>
            </div>
        </div>`;
}

    